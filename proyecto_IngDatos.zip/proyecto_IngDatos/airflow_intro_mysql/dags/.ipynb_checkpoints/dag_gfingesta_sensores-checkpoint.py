# dag_1_ingesta_sensores.py
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from datetime import datetime
import json
import random
import os

default_args = {"owner": "airflow", "retries": 1}

def imprimir_inicio():
    print("Inicio del DAG de Ingesta")

def generar_datos_raw():
    datos = [{"sensor": f"S{i}", "temp": round(random.uniform(15, 35), 2), "ts": datetime.now().isoformat()} for i in range(5)]
    os.makedirs("/tmp", exist_ok=True)
    with open("/tmp/ingesta_raw.json", "w") as f:
        json.dump(datos, f)
    print("Archivo /tmp/ingesta_raw.json creado con 5 registros")

def imprimir_finalizacion():
    print("Finalización del DAG de Ingesta")

with DAG(
    dag_id="dag_1_ingesta_sensores",
    default_args=default_args,
    description="Ingesta simulada de datos de sensores",
    schedule_interval="@once",
    start_date=datetime(2023, 1, 1),
    catchup=False,
) as dag:

    tarea_inicio = PythonOperator(task_id="tarea_inicio", python_callable=imprimir_inicio)

    tarea_generar = PythonOperator(task_id="tarea_generar_datos", python_callable=generar_datos_raw)

    tarea_listar = BashOperator(
        task_id="tarea_listar_tmp",
        bash_command="ls -l /tmp | head -n 20"
    )

    tarea_final = PythonOperator(task_id="tarea_finalizacion", python_callable=imprimir_finalizacion)

    disparar_procesamiento = TriggerDagRunOperator(
        task_id="disparar_dag_2",
        trigger_dag_id="dag_2_procesamiento_limpieza"
    )

    tarea_inicio >> tarea_generar >> tarea_listar >> tarea_final >> disparar_procesamiento
