# dag_2_procesamiento_limpieza.py
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.operators.empty import EmptyOperator
from datetime import datetime
import json
import os

default_args = {"owner": "airflow", "retries": 1}

def validar_datos():
    ruta = "/tmp/ingesta_raw.json"
    assert os.path.exists(ruta), "No existe /tmp/ingesta_raw.json (ejecuta primero dag_1)"
    with open(ruta) as f:
        datos = json.load(f)
    assert isinstance(datos, list) and len(datos) > 0, "El archivo no contiene una lista con registros"
    print(f"Validación OK. Registros: {len(datos)}")

def transformar_datos():
    with open("/tmp/ingesta_raw.json") as f:
        datos = json.load(f)
    # Transformación muy simple: añadir campo 'ok' y normalizar nombre
    for d in datos:
        d["sensor"] = d["sensor"].upper()
        d["ok"] = True
    with open("/tmp/datos_procesados.json", "w") as f:
        json.dump(datos, f)
    print("Transformación hecha → /tmp/datos_procesados.json")

def imprimir_final():
    print("Procesamiento completado")

with DAG(
    dag_id="dag_2_procesamiento_limpieza",
    default_args=default_args,
    description="Validación y transformación de datos",
    schedule_interval="@once",
    start_date=datetime(2023, 1, 1),
    catchup=False,
) as dag:

    inicio = EmptyOperator(task_id="inicio")

    validar = PythonOperator(task_id="validar_datos", python_callable=validar_datos)

    transformar = PythonOperator(task_id="transformar_datos", python_callable=transformar_datos)

    fin = PythonOperator(task_id="finalizacion", python_callable=imprimir_final)

    disparar_entrenamiento = TriggerDagRunOperator(
        task_id="disparar_dag_3",
        trigger_dag_id="dag_3_entrenamiento_modelo"
    )

    inicio >> validar >> transformar >> fin >> disparar_entrenamiento
